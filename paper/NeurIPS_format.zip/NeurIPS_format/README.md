# FeatureScalpel paper (NeurIPS format)

- `main.tex`: the full paper draft on the official `neurips_2025.sty` (preprint mode, author names shown). Switch the style option on line 9 for an anonymised review copy, a workshop, or camera-ready.
- `template_blank.tex`: the empty skeleton with a guidance comment under each heading.
- `checklist.tex`: the NeurIPS Paper Checklist, answered. Check every answer and justification before use; items with `\todo` need action.
- `references.bib`: bibliography, copied from the project report. **Verify each entry against the paper's own page.** Entries marked `CHECK` were written from memory; author names are initials where the full names were not verified.
- `figures/`: figures drawn from stored result files (Appendix D of the report lists the data and script for each).
- `official_instructions/`: the official example and formatting instructions.

Compile: `tectonic -X compile main.tex`, or upload the folder to Overleaf (pdfLaTeX + BibTeX, run twice).

Red `[TODO: ...]` marks remain: author emails, the statement on AI assistance, licences, the public repository link.
